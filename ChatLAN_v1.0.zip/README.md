# ChatLAN
### Commands

- /upload [file_path]       If it does not exist create a "files" directory in the project, if the file does not exist will create it with the original content, if it is already exist will overrite it
- /files                    Will show a list of the file in the "files" directory
- /show [file_name]         Will show the file content line by line